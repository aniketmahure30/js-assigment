const addbutton = document.querySelector('.addbutton');
let input =  document.querySelector('.input');
const container =  document.querySelector('.container');

class item{
    constructor(itemName){
        // create the item div
        this.createDiv(itemName);
    }

    createDiv(itemName){
        let input = document.createElement('input');
        input.value= itemName;
        input.disabled = true;
        input.classList.add('item_input');
        input.type ="text";

        let itembox =  document.createElement('div')
        itembox.classList.add('item');

        let removebutton =  document.createElement('button');
        removebutton.innerHTML = "REMOVE";
        removebutton.classList.add('removebutton');

        container.appendChild(itembox);
        
        itembox.appendChild(input);

        itembox.appendChild(removebutton);
        

        removebutton.addEventListener('click',() => this.remove(itembox));
    }


    remove(item){
        container.removeChild(item);
    }
}

function check(){
    if(input.value != ""){
        new item(input.value);
        input.value = "";
    }
}

addbutton.addEventListener('click',check);
window.addEventListener('keydown',(e) =>{
    if(e.which == 13){
        check();
    }
})


// window.localStorage.setItem('item',JSON.stringify(itembox));

// window.localStorage.getItem('item');
